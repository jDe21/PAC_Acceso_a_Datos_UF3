package ejercicios;

import java.io.Serializable;

//clase Profesor
public class Profesor implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String sexo;
    private static int idSiguiente=1;

    //constructor1
    public Profesor(){
    }

    //constructor2
    public Profesor(String nombre, String sexo){
        this.nombre=nombre;
        this.sexo=sexo;
        id = idSiguiente;
        idSiguiente++;
    }

    //getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    //toString()
    public String toString() {
        return "Profesor{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", sexo='" + sexo + '\'' +
                '}';
    }
}
