package ejercicios;

import com.thoughtworks.xstream.XStream;

import java.io.*;

public class Main {

    public static void main(String[] args) {

        Alumno anabel = new Alumno("Anabel", "española", 26, "M");  //instancias profesores
        Profesor jesus = new Profesor("Jesús", "H");  //instancias profesores
        Profesor alvaro = new Profesor("Álvaro", "H");
        Modulo accesoDatos = new Modulo ("Acceso a datos", "M06"); //instancia modulo

        escritorXML(anabel, "anabel"); //escritura y lectura instancia alumno xml
        lectorXML(anabel, "anabel");

        escritorXML(jesus, "jesus"); //escritura y lectura instancias profesores xml
        lectorXML(jesus, "jesus");
        escritorXML(alvaro, "alvaro");
        lectorXML(alvaro, "alvaro");

        escritorXML(accesoDatos, "accesoDatos"); //escritura y lectura instancia modulo
        lectorXML(accesoDatos, "accesoDatos");
    }

    //funcion para escribir un tipo generico (en este caso un objeto) a fichero binario xml
    public static <T> void escritorXML(T objeto, String nombre) {
        File file = new File("ficheros/" + nombre + ".xml");    //crear fichero en carpeta ficheros con el nombre pasado por parametro
        try {
            FileOutputStream fichero = new FileOutputStream(file,true); //abrir el flujo de salida de datos en la variable fichero, habilito la opcion append
            ObjectOutputStream nexo = new ObjectOutputStream(fichero);//variable nexo de tipo objectoutput para habilitar la posibilidad de escribir en el fichero
            nexo.writeObject(objeto);//se realiza la escritura con la funcion writeObject()
        } catch (FileNotFoundException e) { //captura de las posibles excepciones que pueden darse
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        //funcion para leer un tipo generico  (en este caso un objeto) almacenado en un fichero binario xml
        public static <T> void lectorXML (T objeto, String nombre) {
            File file = new File ("ficheros/" + nombre + ".xml");
            try {
                FileInputStream fichero = new FileInputStream(file);    //se abre el flujo de entrada de datos en la variable fichero
                ObjectInputStream nexo = new ObjectInputStream(fichero); //variable nexo de tipo objectinput que habilita la posibilidad de leer el fichero
                nexo.readObject(); //se realiza la lectura del fichero con la funcion readObject()
                } catch (FileNotFoundException e) { //captura de las posibles excepciones que pueden darse
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            System.out.println(objeto.toString()); //mostramos el toString del objeto pasado por parámetro a la funcion tras realizar la lectura de datos.
}
}
